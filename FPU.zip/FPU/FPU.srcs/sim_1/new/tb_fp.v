`timescale 1ns / 1ps

// ============================================================================
// SELF-CHECKING TESTBENCH
// IEEE-754 Binary64 Floating-Point Multiplier
//
// This testbench:
//   1. Checks directed special-case tests.
//   2. Checks all five rounding modes on boundary/rounding cases.
//   3. Checks 100 additional pseudo-random finite operand combinations.
//   4. Verifies both the 64-bit result and exception flags.
//   5. Prints a final PASS/FAIL summary.
//
// Rounding modes:
//   000 : RoundTiesToEven
//   001 : RoundTowardZero
//   010 : RoundTowardPositive
//   011 : RoundTowardNegative
//   100 : RoundTiesToAway
// ============================================================================

module tb_fp_selfcheck;

    reg [63:0] A;
    reg [63:0] B;
    reg [2:0]  rounding_mode;

    wire [63:0] result;
    wire invalid;
    wire overflow;
    wire underflow;
    wire inexact;

    integer pass_count;
    integer fail_count;
    integer total_count;

    // ------------------------------------------------------------------------
    // DUT
    // ------------------------------------------------------------------------

    floatingpoint_ieee dut (
        .A(A),
        .B(B),
        .rounding_mode(rounding_mode),
        .final_product(result),
        .invalid(invalid),
        .overflow(overflow),
        .underflow(underflow),
        .inexact(inexact)
    );

    // ------------------------------------------------------------------------
    // Self-checking task
    // ------------------------------------------------------------------------

    task check_test;
        input [63:0]  a_in;
        input [63:0]  b_in;
        input [2:0]   rm_in;
        input [63:0]  expected_result;
        input         expected_invalid;
        input         expected_overflow;
        input         expected_underflow;
        input         expected_inexact;
        input [255:0] test_name;

        begin
            A = a_in;
            B = b_in;
            rounding_mode = rm_in;

            #1;

            total_count = total_count + 1;

            if ((result === expected_result) &&
                (invalid === expected_invalid) &&
                (overflow === expected_overflow) &&
                (underflow === expected_underflow) &&
                (inexact === expected_inexact)) begin

                pass_count = pass_count + 1;

                $display("[PASS] %0s | RM=%b | RESULT=%h",
                         test_name, rm_in, result);
            end
            else begin

                fail_count = fail_count + 1;

                $display("[FAIL] %0s | RM=%b", test_name, rm_in);
                $display("       A          = %h", A);
                $display("       B          = %h", B);
                $display("       Expected   = %h", expected_result);
                $display("       Actual     = %h", result);
                $display("       Expected F = I:%b O:%b U:%b X:%b",
                         expected_invalid,
                         expected_overflow,
                         expected_underflow,
                         expected_inexact);
                $display("       Actual F   = I:%b O:%b U:%b X:%b",
                         invalid,
                         overflow,
                         underflow,
                         inexact);
            end
        end
    endtask

    // ------------------------------------------------------------------------
    // Convenience task: same operands for all five rounding modes.
    // ------------------------------------------------------------------------

    task check_all_rounding_modes;
        input [63:0]  a_in;
        input [63:0]  b_in;
        input [63:0]  exp_rne;
        input [63:0]  exp_rtz;
        input [63:0]  exp_rup;
        input [63:0]  exp_rdn;
        input [63:0]  exp_rna;
        input         inv;
        input         ov;
        input         uf;
        input         inex;
        input [255:0] test_name;

        begin
            check_test(a_in, b_in, 3'b000,
                       exp_rne, inv, ov, uf, inex, test_name);

            check_test(a_in, b_in, 3'b001,
                       exp_rtz, inv, ov, uf, inex, test_name);

            check_test(a_in, b_in, 3'b010,
                       exp_rup, inv, ov, uf, inex, test_name);

            check_test(a_in, b_in, 3'b011,
                       exp_rdn, inv, ov, uf, inex, test_name);

            check_test(a_in, b_in, 3'b100,
                       exp_rna, inv, ov, uf, inex, test_name);
        end
    endtask

    initial begin

        pass_count = 0;
        fail_count = 0;
        total_count = 0;

        $display("");
        $display("============================================================");
        $display(" IEEE-754 BINARY64 MULTIPLIER SELF-CHECKING TESTBENCH");
        $display("============================================================");
        $display("");

        // ====================================================================
        // BASIC EXACT RESULTS
        // ====================================================================

        check_test(
            64'h0000000000000000,
            64'h0000000000000000,
            3'b000,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "0 * 0"
        );

        check_test(
            64'h8000000000000000,
            64'h3FF0000000000000,
            3'b000,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "-0 * 1"
        );

        check_test(
            64'h8000000000000000,
            64'h8000000000000000,
            3'b000,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "-0 * -0"
        );

        check_test(
            64'h0000000000000000,
            64'h8000000000000000,
            3'b000,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "+0 * -0"
        );

        check_test(
            64'h3FF0000000000000,
            64'h4000000000000000,
            3'b000,
            64'h4000000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "1 * 2"
        );

        check_test(
            64'hBFF0000000000000,
            64'h4000000000000000,
            3'b000,
            64'hC000000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "-1 * 2"
        );

        check_test(
            64'h3FF8000000000000,
            64'h3FF8000000000000,
            3'b000,
            64'h4002000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "1.5 * 1.5"
        );

        check_test(
            64'h4016000000000000,
            64'h401A000000000000,
            3'b000,
            64'h4041E00000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "5.5 * 6.5"
        );

        // ====================================================================
        // EXACT SUBNORMAL / GRADUAL UNDERFLOW
        // ====================================================================

        check_test(
            64'h0000000000000001,
            64'h3FF0000000000000,
            3'b000,
            64'h0000000000000001,
            1'b0, 1'b0, 1'b0, 1'b0,
            "MIN_SUBNORMAL * 1"
        );

        check_test(
            64'h000FFFFFFFFFFFFF,
            64'h3FF0000000000000,
            3'b000,
            64'h000FFFFFFFFFFFFF,
            1'b0, 1'b0, 1'b0, 1'b0,
            "MAX_SUBNORMAL * 1"
        );

        check_test(
            64'h0010000000000000,
            64'h3FE0000000000000,
            3'b000,
            64'h0008000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "MIN_NORMAL * 0.5"
        );

        // ====================================================================
        // ROUNDING TEST: EXACT HALF-TIE
        //
        // (1 + 2^-52) * 1.5
        // RNE/RNA/RUP -> ...0002
        // RTZ/RDN      -> ...0001
        // ====================================================================

        check_all_rounding_modes(
            64'h3FF0000000000001,
            64'h3FF8000000000000,

            64'h3FF8000000000002,
            64'h3FF8000000000001,
            64'h3FF8000000000002,
            64'h3FF8000000000001,
            64'h3FF8000000000002,

            1'b0, 1'b0, 1'b0, 1'b1,
            "POSITIVE HALF-TIE"
        );

        // Negative sign reverses RUP/RDN.
        check_all_rounding_modes(
            64'hBFF0000000000001,
            64'h3FF8000000000000,

            64'hBFF8000000000002,
            64'hBFF8000000000001,
            64'hBFF8000000000001,
            64'hBFF8000000000002,
            64'hBFF8000000000002,

            1'b0, 1'b0, 1'b0, 1'b1,
            "NEGATIVE HALF-TIE"
        );

        // ====================================================================
        // TINY RESULT ROUNDING
        // ====================================================================

        check_all_rounding_modes(
            64'h0000000000000001,
            64'h3FE0000000000000,

            64'h0000000000000000,
            64'h0000000000000000,
            64'h0000000000000001,
            64'h0000000000000000,
            64'h0000000000000001,

            1'b0, 1'b0, 1'b1, 1'b1,
            "MIN_SUBNORMAL * 0.5 POS"
        );

        check_all_rounding_modes(
            64'h8000000000000001,
            64'h3FE0000000000000,

            64'h8000000000000000,
            64'h8000000000000000,
            64'h8000000000000000,
            64'h8000000000000001,
            64'h8000000000000001,

            1'b0, 1'b0, 1'b1, 1'b1,
            "MIN_SUBNORMAL * 0.5 NEG"
        );

        // ====================================================================
        // OVERFLOW
        // ====================================================================

        check_all_rounding_modes(
            64'h7FEFFFFFFFFFFFFF,
            64'h4000000000000000,

            64'h7FF0000000000000,
            64'h7FEFFFFFFFFFFFFF,
            64'h7FF0000000000000,
            64'h7FEFFFFFFFFFFFFF,
            64'h7FF0000000000000,

            1'b0, 1'b1, 1'b0, 1'b1,
            "POSITIVE OVERFLOW"
        );

        check_all_rounding_modes(
            64'hFFEFFFFFFFFFFFFF,
            64'h4000000000000000,

            64'hFFF0000000000000,
            64'hFFEFFFFFFFFFFFFF,
            64'hFFEFFFFFFFFFFFFF,
            64'hFFF0000000000000,
            64'hFFF0000000000000,

            1'b0, 1'b1, 1'b0, 1'b1,
            "NEGATIVE OVERFLOW"
        );

        // ====================================================================
        // INFINITY
        // ====================================================================

        check_test(
            64'h7FF0000000000000,
            64'h3FF0000000000000,
            3'b000,
            64'h7FF0000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "INF * 1"
        );

        check_test(
            64'hFFF0000000000000,
            64'h3FF0000000000000,
            3'b000,
            64'hFFF0000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "-INF * 1"
        );

        check_test(
            64'h7FF0000000000000,
            64'hFFF0000000000000,
            3'b000,
            64'hFFF0000000000000,
            1'b0, 1'b0, 1'b0, 1'b0,
            "INF * -INF"
        );

        check_test(
            64'h7FF0000000000000,
            64'h0000000000000000,
            3'b000,
            64'h7FF8000000000000,
            1'b1, 1'b0, 1'b0, 1'b0,
            "INF * 0"
        );

        check_test(
            64'h7FF0000000000000,
            64'h8000000000000000,
            3'b000,
            64'h7FF8000000000000,
            1'b1, 1'b0, 1'b0, 1'b0,
            "INF * -0"
        );

        // ====================================================================
        // NaN
        // ====================================================================

        check_test(
            64'h7FF8000000000001,
            64'h3FF0000000000000,
            3'b000,
            64'h7FF8000000000001,
            1'b0, 1'b0, 1'b0, 1'b0,
            "QNaN * 1"
        );

        check_test(
            64'h7FF0000000000001,
            64'h3FF0000000000000,
            3'b000,
            64'h7FF8000000000001,
            1'b1, 1'b0, 1'b0, 1'b0,
            "SNaN * 1"
        );

        check_test(
            64'h3FF0000000000000,
            64'h7FF8000000001234,
            3'b000,
            64'h7FF8000000001234,
            1'b0, 1'b0, 1'b0, 1'b0,
            "1 * QNaN"
        );

        check_test(
            64'h3FF0000000000000,
            64'h7FF0000000001234,
            3'b000,
            64'h7FF8000000001234,
            1'b1, 1'b0, 1'b0, 1'b0,
            "1 * SNaN"
        );

        check_test(
            64'h7FF0000000001111,
            64'h7FF0000000002222,
            3'b000,
            64'h7FF8000000001111,
            1'b1, 1'b0, 1'b0, 1'b0,
            "SNaN * SNaN"
        );

        check_test(
            64'h7FF8000000001111,
            64'h7FF0000000002222,
            3'b000,
            64'h7FF8000000001111,
            1'b1, 1'b0, 1'b0, 1'b0,
            "QNaN * SNaN"
        );

        // ====================================================================
        // ADDITIONAL EXACT/INEXACT NORMAL TESTS
        // ====================================================================

        check_test(
            64'h3FF199999999999A,
            64'h3FF199999999999A,
            3'b000,
            64'h3FF35C28F5C28F5D,
            1'b0, 1'b0, 1'b0, 1'b1,
            "1.1 * 1.1 RNE"
        );

        check_test(
            64'h3FF3333333333333,
            64'h3FF3333333333333,
            3'b000,
            64'h3FF70A3D70A3D70A,
            1'b0, 1'b0, 1'b0, 1'b1,
            "1.2 * 1.2 RNE"
        );

        // ====================================================================
        // 100 RANDOM FINITE TESTS
        // Expected values are precomputed from exact binary64 arithmetic.
        // ====================================================================
        check_test(
            64'h800C923A4D82C616,
            64'h3FFB4A7DBE466AE1,
            3'b001,
            64'h801571497C5A70B7,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_000"
        );
        check_test(
            64'hB265C06798D0D92C,
            64'h0022DE8DF730BC5E,
            3'b010,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_001"
        );
        check_test(
            64'h13E3F688A42F573A,
            64'h35E385646D6CAA71,
            3'b010,
            64'h09D85B30E02A1AE4,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_002"
        );
        check_test(
            64'h23BBA1F9D818A332,
            64'hAF4411E8DA72184A,
            3'b010,
            64'h931154B346BF8DDC,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_003"
        );
        check_test(
            64'h56B0596CE4FEF32C,
            64'hAAC2FFE39759165C,
            3'b001,
            64'hC1836A1448805DAD,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_004"
        );
        check_test(
            64'hBFD6E2FEDC41E920,
            64'h000E3AF14A4FE97C,
            3'b100,
            64'h800516BBC080C682,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_005"
        );
        check_test(
            64'h677B6151C526BACE,
            64'h000A286395368E4D,
            3'b100,
            64'h279161F0D126AEE7,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_006"
        );
        check_test(
            64'hEFF91F715584D0A1,
            64'h3C2FF7478A5EE285,
            3'b100,
            64'hEC391898A80A4FF9,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_007"
        );
        check_test(
            64'hBFC34727B5C94A07,
            64'hF690D2276CE41B00,
            3'b100,
            64'h7664445D1F9F2996,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_008"
        );
        check_test(
            64'h80095FE3F71AF279,
            64'h5DB0332B8DA481D1,
            3'b001,
            64'h9DC2FBBE44E158B0,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_009"
        );
        check_test(
            64'h800AE561B1D466C1,
            64'hE424D6EB83DD59C2,
            3'b010,
            64'h243C622CF797550A,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_010"
        );
        check_test(
            64'hD54BE994462451D7,
            64'h3FEAAD1D4D371F1C,
            3'b011,
            64'hD54744C8D1A137CD,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_011"
        );
        check_test(
            64'hE3CF8D42263AB673,
            64'hBFF6AC29DCBD7278,
            3'b001,
            64'h63D65ADE04788BF2,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_012"
        );
        check_test(
            64'h72E07935BE01BA09,
            64'h69FA2D48B96A104D,
            3'b010,
            64'h7FF0000000000000,
            1'b0, 1'b1, 1'b0, 1'b1,
            "RANDOM_013"
        );
        check_test(
            64'h0001DCB6ABEAED7E,
            64'h209A3024EE8EAEE8,
            3'b011,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_014"
        );
        check_test(
            64'h91C462864B669601,
            64'h8F156AD4F0083463,
            3'b000,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_015"
        );
        check_test(
            64'h8AB9FB81AAF1F0DD,
            64'h9ADCD93F9D7B849C,
            3'b001,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_016"
        );
        check_test(
            64'h00089F5DB1CE9246,
            64'hA18E186B9E272EEC,
            3'b010,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_017"
        );
        check_test(
            64'hBFC754C18892A30B,
            64'hD43D972A765F7D71,
            3'b011,
            64'h541593064A8D83AF,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_018"
        );
        check_test(
            64'h343EDC6C1C9C3A1D,
            64'hBC9358D204627F6F,
            3'b010,
            64'hB0E2A888E50B7756,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_019"
        );
        check_test(
            64'h80220FCE93C16C4F,
            64'h3FDC5653102CAA65,
            3'b010,
            64'h800FFE8E1E974308,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_020"
        );
        check_test(
            64'hEA86649305F2825A,
            64'h333E233C2B7CFAA5,
            3'b000,
            64'hDDD516F1F1642149,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_021"
        );
        check_test(
            64'h0871580FB84318EE,
            64'h69E8EAAC0A70F709,
            3'b100,
            64'h326B0279F845F58D,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_022"
        );
        check_test(
            64'hFCCB12474FF8AAF1,
            64'h3EF9942E18A512F0,
            3'b010,
            64'hFBD5A3A33F6C0259,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_023"
        );
        check_test(
            64'hF1239B668B240FAC,
            64'h59FEF0CC7B06437E,
            3'b010,
            64'hFFEFFFFFFFFFFFFF,
            1'b0, 1'b1, 1'b0, 1'b1,
            "RANDOM_024"
        );
        check_test(
            64'hBFF143461E7D6C84,
            64'h6DC7D8F65DD053E0,
            3'b001,
            64'hEDC9BACACDFDCA9E,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_025"
        );
        check_test(
            64'hBC14C695C8FC95F2,
            64'h513A6F5041ABE0C7,
            3'b011,
            64'hCD61299EA5F7D3D5,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_026"
        );
        check_test(
            64'hA56A513214820BDF,
            64'h09F9C9B1DDB53834,
            3'b011,
            64'h8000000000000001,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_027"
        );
        check_test(
            64'h903EBA48A1BE32DF,
            64'h839D5C9A1F6F8CCC,
            3'b001,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_028"
        );
        check_test(
            64'h000D01F45386FE21,
            64'h803F7AF633558447,
            3'b001,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_029"
        );
        check_test(
            64'h13BE6338E7854989,
            64'h3FE40781DAF0A1CA,
            3'b100,
            64'h13B30524950BCDE6,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_030"
        );
        check_test(
            64'hEA872A41A179630F,
            64'hB4BF716E1CEDAAEA,
            3'b100,
            64'h5F56C30C82626DCB,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_031"
        );
        check_test(
            64'hC27439F2C0CD87A8,
            64'h800D5D881D08C96F,
            3'b001,
            64'h0290E55220EB334B,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_032"
        );
        check_test(
            64'h0D4697F6053A80A6,
            64'h73E496630C7CDFAB,
            3'b010,
            64'h413D125006DEB3AE,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_033"
        );
        check_test(
            64'h6BE07057C94552FB,
            64'hA85CD9F0040E1D66,
            3'b010,
            64'hD44DA483E0226EF0,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_034"
        );
        check_test(
            64'h9D076C68688FE217,
            64'h385DDAEA21F179DA,
            3'b010,
            64'h9575DA7C879EC304,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_035"
        );
        check_test(
            64'h0005D47DDEC16B53,
            64'h8015BEB87F56AD47,
            3'b000,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_036"
        );
        check_test(
            64'h2DF2C9BDF0A4E20B,
            64'h216256CBA187C1AC,
            3'b011,
            64'h0F6588E128EE429A,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_037"
        );
        check_test(
            64'hC8738009F5672F59,
            64'h6708083FD8832F60,
            3'b011,
            64'hEF8D4A1CC51D1964,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_038"
        );
        check_test(
            64'hEFAFBF4692D5ABE4,
            64'h8029FBC3A7AA0E14,
            3'b001,
            64'h2FE9C7359033A779,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_039"
        );
        check_test(
            64'h803AE3B2CA7DF2CE,
            64'h0007A04A53676CF7,
            3'b001,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_040"
        );
        check_test(
            64'h7EDA33722089152F,
            64'hF994144CC1BA7D20,
            3'b011,
            64'hFFF0000000000000,
            1'b0, 1'b1, 1'b0, 1'b1,
            "RANDOM_041"
        );
        check_test(
            64'hBB542D9CDF609A64,
            64'hF6F11AE7EC2B8AA6,
            3'b000,
            64'h7255926548A22D57,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_042"
        );
        check_test(
            64'h0BA1340778A9A28B,
            64'h000E03C76233D6FA,
            3'b100,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_043"
        );
        check_test(
            64'h002D607FFAA908CA,
            64'hE5CDC543513206F9,
            3'b100,
            64'hA60B548BDB9E7688,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_044"
        );
        check_test(
            64'hDFD23D20C7D9274B,
            64'h000A85C92F057A3C,
            3'b011,
            64'h9FE7FD6BE5D525F3,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_045"
        );
        check_test(
            64'h000CB8B65357D2C5,
            64'hBFC27D085AE95672,
            3'b010,
            64'h8001D666DA5A33A2,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_046"
        );
        check_test(
            64'h0A27E27FCCBC695C,
            64'hAC6281E643B65BF2,
            3'b000,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_047"
        );
        check_test(
            64'h800EF85BDA432D9E,
            64'hFE698549E23024E0,
            3'b001,
            64'h3E87E0C521537683,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_048"
        );
        check_test(
            64'h2455C5B5E06FB98D,
            64'h3B043C4561EBCFA8,
            3'b001,
            64'h1F6B89272C7523DC,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_049"
        );
        check_test(
            64'h85E31DC897FE5DD5,
            64'h800428212F0D323D,
            3'b100,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_050"
        );
        check_test(
            64'h800CADFCE0FB622E,
            64'hCE96E375A8FCA321,
            3'b010,
            64'h0EB2237D6745D77F,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_051"
        );
        check_test(
            64'hA1E930AFFA9D5647,
            64'h80246F0323187D2D,
            3'b100,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_052"
        );
        check_test(
            64'h43694E83309B83A7,
            64'h0AA6F0C87666F327,
            3'b001,
            64'h0E22246591AE56FA,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_053"
        );
        check_test(
            64'hCA2ACE4764AE258C,
            64'h1CDF69BE56328A15,
            3'b100,
            64'hA71A506974C7AB6E,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_054"
        );
        check_test(
            64'h73D12484E258462A,
            64'h8009909C5D0D2484,
            3'b010,
            64'hB3E47EF5E61173F5,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_055"
        );
        check_test(
            64'h46B753354651BE57,
            64'h8EACFABED95727E8,
            3'b001,
            64'h95751F93CA34FF44,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_056"
        );
        check_test(
            64'hEB37581C645B522B,
            64'h801F2D8308C9ECDA,
            3'b011,
            64'h2B66BE8F0043282F,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_057"
        );
        check_test(
            64'h409F24A272F8345C,
            64'hB75F7B313DBEEF01,
            3'b011,
            64'hB80EA3621BFAC499,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_058"
        );
        check_test(
            64'hC4C39990BE818B5C,
            64'hAEB7C8710C95CFBE,
            3'b000,
            64'h338D224A1F207E33,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_059"
        );
        check_test(
            64'hF71E9C32065E9FF6,
            64'h8946846EE69B986A,
            3'b000,
            64'h40758A10C83EC81E,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_060"
        );
        check_test(
            64'h933113F1EB7783AF,
            64'h4D76D9D1FC742610,
            3'b011,
            64'hA0B863EB46CC093B,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_061"
        );
        check_test(
            64'hBD3E130ACB0311EE,
            64'h800A91CB6AC37AB2,
            3'b001,
            64'h000000000000013D,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_062"
        );
        check_test(
            64'hCDC6F958028A15E6,
            64'h000AAD06D7A50B0F,
            3'b011,
            64'h8DDEA891B8AC9B1E,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_063"
        );
        check_test(
            64'h3FD2427CC554A53D,
            64'h0E8E8ECAA4663AD6,
            3'b000,
            64'h0E716FCFA42DB520,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_064"
        );
        check_test(
            64'h59487D0A6C9A26D7,
            64'h724331563444FE11,
            3'b001,
            64'h7FEFFFFFFFFFFFFF,
            1'b0, 1'b1, 1'b0, 1'b1,
            "RANDOM_065"
        );
        check_test(
            64'hEB2754938C178EFF,
            64'hD209068B6C228223,
            3'b010,
            64'h7D423ED8C7542F60,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_066"
        );
        check_test(
            64'h4121EC66E157DD4B,
            64'hE4E6CC33A26884A0,
            3'b001,
            64'hE61989CD6D0885AC,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_067"
        );
        check_test(
            64'hC7349749861239B6,
            64'hC00C7CDF78FB5C63,
            3'b010,
            64'h475254BA5E58E941,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_068"
        );
        check_test(
            64'h3FCD9C226FA23EF4,
            64'h800C29378896FF46,
            3'b001,
            64'h8002D02C162E9672,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_069"
        );
        check_test(
            64'h0001AEFF5BBF44F3,
            64'h70FCF9D64130A2A2,
            3'b000,
            64'h30E86446902FFF42,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_070"
        );
        check_test(
            64'h002F60D7BDDAFFD6,
            64'hF9AB5FEE82701909,
            3'b011,
            64'hB9EAD7C768D85604,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_071"
        );
        check_test(
            64'hD09746CB86B4B3F4,
            64'h000BB20B6DB31E7C,
            3'b100,
            64'h90B103B02519A18A,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_072"
        );
        check_test(
            64'hB5279D5066DEA104,
            64'h000BFFADEAE8EC4C,
            3'b011,
            64'h8000000000000001,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_073"
        );
        check_test(
            64'h4C010F920B5C9C29,
            64'h169D41985744AEC2,
            3'b000,
            64'h22AF322A66DF55D7,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_074"
        );
        check_test(
            64'hBDC8D279BD595EFE,
            64'hA69A859DCFDF2E1B,
            3'b100,
            64'h247492A81DB783A4,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_075"
        );
        check_test(
            64'h3F98715DC4E85986,
            64'h0005028CD953F21F,
            3'b011,
            64'h00001E9D4A94DDE6,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_076"
        );
        check_test(
            64'hDCBE109048C0708E,
            64'h8A3A9BB1F87056B5,
            3'b001,
            64'h2708FFBCAB04BBA0,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_077"
        );
        check_test(
            64'hE22D1A7B7B4732DC,
            64'h184231953838EA1D,
            3'b100,
            64'hBA808BFDB8DDE301,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_078"
        );
        check_test(
            64'h4F3A47161BAF10C0,
            64'h000463EAF6F6E4AD,
            3'b011,
            64'h0F3CD77D13D352DA,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_079"
        );
        check_test(
            64'h8007A4FE769062F7,
            64'h0004E47D88C1C826,
            3'b010,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_080"
        );
        check_test(
            64'h80190AEE947CFC16,
            64'h2485A24A4A4170A9,
            3'b100,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_081"
        );
        check_test(
            64'h800613082D5238D9,
            64'hAE24650D8236F384,
            3'b000,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_082"
        );
        check_test(
            64'h2BE4E1C683A04933,
            64'h57A497531675DEA1,
            3'b000,
            64'h439ADFB75688A581,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_083"
        );
        check_test(
            64'hEDE89DAFCF36A1BC,
            64'h2A428F04CE79F6A2,
            3'b001,
            64'hD83C8D6E817F3D85,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_084"
        );
        check_test(
            64'hE688BC65D4E6B654,
            64'h6A8C170036865C7B,
            3'b000,
            64'hFFF0000000000000,
            1'b0, 1'b1, 1'b0, 1'b1,
            "RANDOM_085"
        );
        check_test(
            64'h0004D9994E9E9279,
            64'h2B13F0DBDF42CCC0,
            3'b010,
            64'h0000000000000001,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_086"
        );
        check_test(
            64'hBAF87AD1E8F2FD4A,
            64'h579C08659DE3409F,
            3'b000,
            64'hD2A571E41CBDD02E,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_087"
        );
        check_test(
            64'h29E657A642734C28,
            64'h75C69DEBD395714F,
            3'b010,
            64'h5FBF9509F9991312,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_088"
        );
        check_test(
            64'h7E16E314536A9BC6,
            64'h70F75273606BDE7F,
            3'b011,
            64'h7FEFFFFFFFFFFFFF,
            1'b0, 1'b1, 1'b0, 1'b1,
            "RANDOM_089"
        );
        check_test(
            64'h04CE9A9DD41B2047,
            64'hE295BB94A642EC0B,
            3'b001,
            64'hA774C8DD479D5411,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_090"
        );
        check_test(
            64'h18E240FB4A4949DB,
            64'h0003A5CF7AB1845D,
            3'b000,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_091"
        );
        check_test(
            64'h8007D43900C67532,
            64'h837C7864ACF58FB0,
            3'b011,
            64'h0000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_092"
        );
        check_test(
            64'h690905ABDB400339,
            64'hCD568E66AC6B13F0,
            3'b010,
            64'hF671A33F9A3EEF69,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_093"
        );
        check_test(
            64'hBFF4F0708E1937E0,
            64'h084B3165C202CED5,
            3'b000,
            64'h8851CB31BA159EFE,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_094"
        );
        check_test(
            64'hC28D0F2CA60586EE,
            64'h8057F5C0D92CAFED,
            3'b010,
            64'h02F5C213656E72D3,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_095"
        );
        check_test(
            64'h00023363BE2A75A5,
            64'hA249416201AC6036,
            3'b010,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_096"
        );
        check_test(
            64'h4B3CEADF4CCD5722,
            64'h0BB72AC30105564F,
            3'b100,
            64'h1704EF74FC7549D2,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_097"
        );
        check_test(
            64'h3FE856E185DC0639,
            64'h80374B229D4B22A3,
            3'b000,
            64'h8031B7980CBAE6D3,
            1'b0, 1'b0, 1'b0, 1'b1,
            "RANDOM_098"
        );
        check_test(
            64'h0002834C9831AA00,
            64'h8B398F015955E10F,
            3'b001,
            64'h8000000000000000,
            1'b0, 1'b0, 1'b1, 1'b1,
            "RANDOM_099"
        );

        // ====================================================================
        // SUMMARY
        // ====================================================================

        $display("");
        $display("============================================================");
        $display(" SELF-CHECK SUMMARY");
        $display("============================================================");
        $display("Total tests : %0d", total_count);
        $display("Passed      : %0d", pass_count);
        $display("Failed      : %0d", fail_count);
        $display("============================================================");

        if (fail_count == 0) begin
            $display("RESULT      : ALL TESTS PASSED");
        end
        else begin
            $display("RESULT      : TESTS FAILED");
        end

        $display("============================================================");
        $display("");

        #1;
        $finish;

    end

endmodule
